void matmult_gpu1(int m, int n, int k, double *A, double *B, double *C);
